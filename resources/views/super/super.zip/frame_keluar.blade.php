@extends('layouts.super')

@section('content')
<div class="card">
    <div class="card-body">
      <h4 class="card-title">Pilih Jenis</h4>
      <div class="template-demo">
        <a href="/super/barangkeluar/frameoriginal" type="button" class="btn btn-primary btn-fw">Original</a>
        <a href="/super/barangkeluar/framebiasa" type="button" class="btn btn-primary btn-fw">Frame</a>

      </div>
    </div>
</div>
@endsection