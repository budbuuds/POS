@extends('layouts.admin')

@section('content')
<div class="card">
    <div class="card-body">
      <h4 class="card-title">Pilih Jenis</h4>
      <div class="template-demo">
        <a href="/barangkeluar/frameoriginal" type="button" class="btn btn-primary btn-fw">Original</a>
        <a href="/barangkeluar/framebiasa" type="button" class="btn btn-primary btn-fw">Frame</a>

      </div>
    </div>
</div>
@endsection